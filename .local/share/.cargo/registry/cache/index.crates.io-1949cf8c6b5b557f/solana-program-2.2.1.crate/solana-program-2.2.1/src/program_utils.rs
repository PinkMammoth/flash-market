pub use solana_bincode::limited_deserialize;
