//! The [ed25519 native program][np].
//!
//! [np]: https://docs.solanalabs.com/runtime/programs#ed25519-program
pub use solana_sdk_ids::ed25519_program::{check_id, id, ID};
