use std::time::Duration;

pub const DEFAULT_TPU_COALESCE: Duration = Duration::from_millis(5);
