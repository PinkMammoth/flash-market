#![cfg(feature = "program")]

pub use solana_program::log::*;
