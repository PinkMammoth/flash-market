//! This module is empty but has not yet been removed because that would
//! technically be a breaking change. There was never anything to import
//! from here.
